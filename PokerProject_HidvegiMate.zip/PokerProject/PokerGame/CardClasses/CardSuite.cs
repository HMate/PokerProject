﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokerProject.PokerGame.CardClasses
{
    public enum CardSuite : int
    {
        Hearts = 0,
        Spades = 1,
        Diamonds = 2,
        Clubs = 3
    }
}
